import React from 'react';

export default function HelpDashboard() {
  return <div>Help Page.</div>;
}
