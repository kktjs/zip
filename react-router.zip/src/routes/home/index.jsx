import React from 'react';
import styles from './index.module.less';

export default function Dashboard() {
  return <div className={styles.warpper}>这里是首页</div>;
}
