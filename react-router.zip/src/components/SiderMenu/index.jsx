import styles from './index.module.less';

export default function SiderMenu() {
  return <div className={styles.wapper}>菜单</div>;
}
