Use an example of `Markdown`.
