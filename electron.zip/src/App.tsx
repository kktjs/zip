const App = () => <div className="App">test</div>;

export default App;
