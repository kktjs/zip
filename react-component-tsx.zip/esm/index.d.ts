import React from 'react';
import './style/index.less';
export interface ButtonProps {
    prefixCls?: string;
    type?: string;
    size?: 'large' | 'default' | 'small';
    active?: boolean;
    disabled?: boolean;
    block?: boolean;
    basic?: boolean;
    loading?: boolean;
    className?: string;
    children?: React.ReactNode;
    htmlType?: React.ButtonHTMLAttributes<HTMLButtonElement>['type'];
}
export default function Button(props?: ButtonProps): JSX.Element;
