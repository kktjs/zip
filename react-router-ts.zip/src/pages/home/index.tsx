import { FC, PropsWithChildren } from 'react';

export const Component: FC<PropsWithChildren> = () => {
  return <div>Home Page</div>;
};
